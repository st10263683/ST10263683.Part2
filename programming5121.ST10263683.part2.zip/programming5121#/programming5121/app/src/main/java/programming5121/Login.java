package programming5121;

public class Login {
    private User user;

    // Constructor to initialize Login object with a user
    public Login(User user) {
        this.user = user;
    }

    // Method to check if username meets formatting requirements
    public boolean checkUserName() {
        return user.getUsername().contains("_") && user.getUsername().length() <= 5;
    }
    
    // Method to check if password meets complexity requirements
    public boolean checkPasswordComplexity() {
        String password = user.getPassword();
        return password.length() >= 8 && password.matches(".*[A-Z].*") &&
                password.matches(".*\\d.*") && password.matches(".*[!@#$%^&*()-+=].*");
    }

    // Method to register a user and return registration status message
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
        }
        return "User registered successfully!";
    }

    // Method to authenticate user login and return login status message
    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) {
            return "Welcome " + user.getFirstname() + " " + user.getLastname() + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Method to verify user login credentials
    public boolean loginUser(String username, String password) {
        return username.equals(user.getUsername()) && password.equals(user.getPassword());
    }
}

