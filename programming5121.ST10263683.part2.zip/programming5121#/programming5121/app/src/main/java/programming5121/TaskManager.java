package programming5121;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TaskManager {

    private List<Task> tasks = new ArrayList<>();

    public void addTasks(Scanner scanner) {
        System.out.print("Enter number of tasks to add: ");
        int numTasks = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < numTasks; i++) {
            System.out.print("Enter task name: ");
            String taskName = scanner.nextLine();

            System.out.print("Enter task description: ");
            String taskDescription;
            while (true) {
                taskDescription = scanner.nextLine();
                if (taskDescription.length() <= 50) {
                    break;
                } else {
                    System.out.println("Please enter a task description of less than 50 characters");
                }
            }

            System.out.print("Enter developer details: ");
            String developerDetails = scanner.nextLine();

            System.out.print("Enter task duration in hours: ");
            int taskDuration = Integer.parseInt(scanner.nextLine());

            System.out.print("Enter task status (To Do, Doing, Done): ");
            String taskStatus;
            while (true) {
                taskStatus = scanner.nextLine();
                if (taskStatus.equalsIgnoreCase("To Do") || taskStatus.equalsIgnoreCase("Doing") || taskStatus.equalsIgnoreCase("Done")) {
                    break;
                } else {
                    System.out.println("Please enter a valid task status (To Do, Doing, Done)");
                }
            }

            Task task = new Task(taskName, tasks.size(), taskDescription, developerDetails, taskDuration, taskStatus);
            tasks.add(task);
            System.out.println("Task successfully captured");
            System.out.println(task.printTaskDetails());
        }

        int totalHours = tasks.stream().mapToInt(Task::getTaskDuration).sum();
        System.out.println("Total number of hours across all tasks: " + totalHours);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TaskManager taskManager = new TaskManager();
        taskManager.addTasks(scanner);
    }
}
