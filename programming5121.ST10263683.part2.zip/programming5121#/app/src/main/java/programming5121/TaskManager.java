package programming5121;

import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

public class TaskManager {

    private List<Task> tasks = new ArrayList<>();

    public void addTasks() {
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter number of tasks to add (enter 3 to stop): "));

        for (int i = 0; i < numTasks; i++) {
            if (numTasks == 3) {
                break;
            }

            String taskName = JOptionPane.showInputDialog("Enter task name: ");

            String taskDescription;
            while (true) {
                taskDescription = JOptionPane.showInputDialog("Enter task description: ");
                if (taskDescription.length() <= 50) {
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
                }
            }

            String developerDetails = JOptionPane.showInputDialog("Enter developer details: ");

            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter task duration in hours: "));

            String taskStatus;
            while (true) {
                taskStatus = JOptionPane.showInputDialog("Enter task status (To Do, Doing, Done): ");
                if (taskStatus.equalsIgnoreCase("To Do") || taskStatus.equalsIgnoreCase("Doing") || taskStatus.equalsIgnoreCase("Done")) {
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a valid task status (To Do, Doing, Done)");
                }
            }

            Task task = new Task(taskName, tasks.size(), taskDescription, developerDetails, taskDuration, taskStatus);
        }
    }
}