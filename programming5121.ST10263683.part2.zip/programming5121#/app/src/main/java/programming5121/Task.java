package programming5121;

import javax.swing.JOptionPane;

public class Task {

    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskID;
    private String taskStatus;

    public Task(String taskName, int taskNumber, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskNumber = taskNumber;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
        this.taskID = createTaskID();
    }

    public Task() {

    }

    public boolean checkTaskDescription() {
        return this.taskDescription.length() <= 50;
    }

    private String createTaskID() {
        String taskID = taskName.substring(0, 2).toUpperCase() + ":" + taskNumber + ":" + developerDetails.substring(developerDetails.length() - 3).toUpperCase();
        return taskID;
    }

    public String printTaskDetails() {
        return "Task Status: " + taskStatus + "\n" +
                "Developer Details: " + developerDetails + "\n" +
                "Task Number: " + taskNumber + "\n" +
                "Task Name: " + taskName + "\n" +
                "Task Description: " + taskDescription + "\n" +
                "Task ID: " + taskID + "\n" +
                "Task Duration: " + taskDuration + " hrs";
    }

    public int getTaskDuration() {
        return taskDuration;
    }

    public static void main(String[] args) {
        Task task = new Task();

        String taskName = JOptionPane.showInputDialog("Enter task name:");
        String taskDescription = JOptionPane.showInputDialog("Enter task description:");
        String developerDetails = JOptionPane.showInputDialog("Enter developer details:");
        int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter task duration in hours:"));
        String taskStatus = JOptionPane.showInputDialog("Enter task status (To Do, Doing, Done):");

        task = new Task(taskName, 0, taskDescription, developerDetails, taskDuration, taskStatus);
        JOptionPane.showMessageDialog(null, task.printTaskDetails());
    }
}
