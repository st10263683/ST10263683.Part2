public class TaskTest {
    
    @Test
    public void testCheckTaskDescription() {
        Task task = new Task("Login Feature", 0, "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertTrue(task.checkTaskDescription(), "Task description should be valid.");
        
        Task invalidTask = new Task("Add Task Feature", 1, "This is a very long task description that exceeds the fifty character limit.", "Mike Smith", 10, "Doing");
        assertFalse(invalidTask.checkTaskDescription(), "Task description should be invalid.");
    }

    @Test
    public void testCreateTaskID() {
        Task task = new Task("Login Feature", 0, "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertEquals("LO:0:SON", task.createTaskID(), "Task ID should be LO:0:SON.");
    }

    @Test
    public void testReturnTotalHours() {
        Task task1 = new Task("Login Feature", 0, "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        Task task2 = new Task("Add Task Feature", 1, "Create Add Task feature to add task users", "Mike Smith", 10, "Doing");

        int totalHours = task1.getTaskDuration() + task2.getTaskDuration();
        assertEquals(18, totalHours, "Total hours should be 18.");
    }
}
